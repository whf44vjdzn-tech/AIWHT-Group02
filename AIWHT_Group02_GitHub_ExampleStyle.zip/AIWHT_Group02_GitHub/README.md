# AI Withholding Tax Assistant — Group 02

Prototype งาน AC317 การบัญชีภาษีอากร

## GitHub Pages
1. สร้าง Repository ใหม่และอัปโหลดไฟล์/โฟลเดอร์ทั้งหมด
2. ไปที่ Settings → Pages
3. เลือก Deploy from a branch → branch `main` → folder `/ (root)` → Save
4. รอระบบ deploy แล้วเปิด URL ที่ GitHub Pages แสดง

## โครงสร้างไฟล์
- `index.html` — เว็บไซต์ Prototype สำหรับ GitHub Pages
- `MASTER_PROMPT.md` — Master Prompt ฉบับสุดท้าย
- `data/tax_knowledge.json` — Tax Knowledge Base
- `data/test_cases.csv` — ชุดโจทย์ 10 กรณี
- `data/Group02_TaxKnowledge.xlsx` — ตารางฐานความรู้ภาษี
- `data/Group02_TestResults.xlsx` — แบบบันทึกผลทดสอบก่อน/หลังปรับปรุง
- `docs/Group02_MasterPrompt.docx` — Master Prompt ฉบับ Word
- `docs/LEGAL_REFERENCES.md` — ข้อกฎหมายรายกรณี
- `docs/WORKFLOW.md` — Workflow

## สมมติฐานร่วมจากใบงาน
บริษัท ABC จำกัด จดทะเบียนในประเทศไทย; ผู้รับตามโจทย์เป็นผู้มีถิ่นที่อยู่/บริษัทไทย; วันที่จ่าย 9 พฤศจิกายน 2569; ใช้วิธีปกติ ไม่ใช้ e-Withholding Tax; พิจารณา VAT เฉพาะที่ระบุ

## สมาชิกกลุ่ม 02
| รหัส | ชื่อ-นามสกุล |
|---|---|
| 2410211100213 | อจิรวฎี รุ่งพราน |
| 2410211100224 | ปารีส บัวบานพร้อม |
| 2410211100225 | สารินี เพียรธัญกิจ |
| 2410211100249 | วรัญญา เชิงเทิน |
| 2410211100250 | พิมพ์ชนก พัฒนกัลป์ |

## แหล่งกฎหมายหลัก
- https://www.rd.go.th/3479.html
- https://www.rd.go.th/3326.html

## ข้อจำกัด
Prototype เพื่อการศึกษา ไม่ได้เชื่อมต่อ AI หรือฐานกฎหมายแบบเรียลไทม์ ผล AI ครั้งแรกและหลังปรับปรุงต้องบันทึกจากการทดลองจริงในไฟล์ Excel ห้ามใช้ผลคาดหวังแทนผลจริง
